the program has shift reduce errors and a reduce reduce error and there's no error
handling but I just need to get this in. Otherwise I think it works.
