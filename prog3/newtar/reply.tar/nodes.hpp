// nodes.hpp
// Colton Roach
// cosc 4785 Fall 2022
// October 19, 2022

#ifndef NODES_HPP
#define NODES_HPP
#include<iostream>
#include<string>

using std::string;
using std::endl;
using std::ostream;

class Node
{
    public:
        Node(string lbl="", int pt=0);
        virtual ~Node();
        
        string getLabel();
        int getProdType();

        void setLabel(string lbl);
        void setProdType(int pt);

    protected:
        string label;
        int prodType;
};


class nodeID : public Node
{
    public:
        nodeID(string s);

        string getId();

        void setId(string i);

    protected:
        string id;
};

class nodeNum : public Node
{
    public:
        nodeNum(int n):num(n){}

        int getNum(){return num;}

        void setNum(int n){num=n;}

    protected:
        int num;
};

class nodeMultibrackets : public Node
{
    public: 

    protected:
};


class nodeSimpleType : public Node
{
    public:
        nodeSimpleType();
};


class nodeType : public Node
{
    public:
        nodeType(Node* st);

        Node* getNodeSimpleType();
        
        void setNodeSimpleType(Node* st);

    protected:
        Node* simpleType;
};


class nodeExp : public Node
{
    public:
        

    protected:
};


class nodeVarDec : public Node
{
    public:
        //nodeVarDec(Node* t, Node* i);
        nodeVarDec(Node* fi, Node* si);
        //nodeVarDec(Node* t, Node* mb, Node* i);
        nodeVarDec(Node* fi, Node* mb, Node* si);
        
        Node* getNodeType();
        Node* getNodeFirstID();
        Node* getNodeSecondID();
        Node* getNodeMultibrackets();

        void setNodeType(Node* nt);
        void setNodeFirstID(Node* i);
        void setNodeSecondID(Node* i);
        void setNodeMultibrackets(Node* mb);
        
    protected:
        Node* type;
        Node* firstId;
        Node* secondId;
        Node* multibrackets;        
};


class nodeElements : public Node
{
    public:
        nodeElements(Node* vd);
        //nodeElements(Node* e);

        Node* getNodeVarDec();
        Node* getNodeExp();

        void setNodeVarDec(Node* vd);
        void setNodeExp(Node* e);

    protected:
        Node* vardec;
        Node* exp;
};


class nodeProgram : public Node
{
    public:
        nodeProgram(Node* ne);
        nodeProgram(Node* np, Node* ne);
        
        Node* getNodeElements();
        Node* getNodeProgram();

        void setNodeElements(Node* ne);
        void setNodeProgram(Node* np);

    protected:
        Node* elements;
        Node* program;
};


#endif
