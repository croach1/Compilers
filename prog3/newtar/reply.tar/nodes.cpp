//Program 3
//Colton Roach
//October 17, 2022
//COSC 4785

#include "nodes.hpp"


//Node Class

Node::Node(string lbl, int pt) :
    label(lbl),prodType(pt)
{    
    //reset();
}

Node::~Node(){}

//Getters
string Node::getLabel()
{
    return label;
}
int Node::getProdType()
{
    return prodType;
}

//Setters
void Node::setLabel(string lbl)
{
    label = lbl;
}
void Node::setProdType(int pt)
{
    prodType = pt;
}


//NodeProgram Subclass---------------------------------------------------------------
//Constructors
nodeProgram::nodeProgram(Node *ne) :
    Node("<program> --> <elements>", 1)
{
    elements = ne;
}
nodeProgram::nodeProgram(Node *np, Node *ne) :
    Node("<program> --> <program> <elements>", 2)
{
    elements = ne;
    program = np;
}

//Getters
Node* nodeProgram::getNodeElements()
{
    return elements;
}
Node* nodeProgram::getNodeProgram()
{
    return program;
}

//Setters
void nodeProgram::setNodeElements(Node *ne)
{
    elements = ne;
}
void nodeProgram::setNodeProgram(Node *np)
{
    program = np;
}


//NodeElements Subclass--------------------------------------------------------------
//Constructors
nodeElements::nodeElements(Node *vd) :
    Node("<elements> --> <vardec>", 1)
{
    vardec = vd;
}
/*
nodeElements::nodeElements(Node *e) :
    Node("<elements> --> <exp> SEMI", 2)
{
    exp = e;
}
*/

//Getters
Node* nodeElements::getNodeVarDec()
{
    return vardec;
}
Node* nodeElements::getNodeExp()
{
    return exp;
}

//Setters
void nodeElements::setNodeVarDec(Node *vd)
{
    vardec = vd;
}
void nodeElements::setNodeExp(Node *e)
{
    exp = e;
}


//NodeVarDec Subclass----------------------------------------------------------------
//Constructors
/*
nodeVarDec::nodeVarDec(Node *tp, Node *id) :
    Node("<vardec> --> <type> ID SEMI", 1)
{
    type = tp;
    firstId = id;
}
*/
nodeVarDec::nodeVarDec(Node *fid, Node *sid) :
    Node("<vardec> --> ID ID SEMI", 2)
{
    firstId = fid;
    secondId = sid;
}
/*
nodeVarDec::nodeVarDec(Node *tp, Node *mb, Node *id) :
    Node("<vardec> --> <type> <multibrackets> ID SEMI", 3)
{
    type = tp;
    multibrackets = mb;
    firstId = id;
}
*/
nodeVarDec::nodeVarDec(Node *fid, Node *mb, Node *sid) :
    Node("<vardec> --> ID <multibrackets> ID SEMI", 4)
{
    firstId = fid;
    secondId = sid;
    multibrackets = mb;
}

//Getters
Node* nodeVarDec::getNodeType()
{
    return type;
}
Node* nodeVarDec::getNodeFirstID()
{
    return firstId;
}
Node* nodeVarDec::getNodeSecondID()
{
    return secondId;
}
Node* nodeVarDec::getNodeMultibrackets()
{
    return multibrackets;
}

//Setters
void nodeVarDec::setNodeType(Node *nt)
{
    type = nt;
}
void nodeVarDec::setNodeFirstID(Node *id)
{
    firstId = id;
}
void nodeVarDec::setNodeSecondID(Node *id)
{
    secondId = id;
}
void nodeVarDec::setNodeMultibrackets(Node *mb)
{
    multibrackets = mb;
}


//NodeType Subclass -----------------------------------------------------------------
//Constructors
nodeType::nodeType(Node *st) :
    Node("<type> --> <simpletype>", 1)
{
    simpleType = st;
}

//Getters
Node* nodeType::getNodeSimpleType()
{
    return simpleType;
}

//Setters
void nodeType::setNodeSimpleType(Node *st)
{
    simpleType = st;
}


//NodeSimpleType Subclass------------------------------------------------------------
//Constructors
nodeSimpleType::nodeSimpleType() :
    Node("<simpletype> --> INT", 1)
{}


//NodeID Subclass--------------------------------------------------------------------
//Constructors
nodeID::nodeID(string i) :
    Node("ID --> " + i, 1)
{
    id = i;
}


