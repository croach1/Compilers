//program2.hpp
//Colton Roach
//September 25, 2022

#ifndef PROGRAM3_HPP
#define PROGRAM3_HPP

extern string token;

#endif
