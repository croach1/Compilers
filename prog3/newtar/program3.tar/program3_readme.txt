There are a couple of issues still but I just need to turn it in and get to the next 
one. I still have a couple of shift reduce errors but did fix most. Also, the tree 
doesn't print quite correctly in cases where a node can contain a node of its own 
type, for example program --> program or name --> name. Other than that thank you
again for working with me and I will get started on the next assignment right away
and try to get caught up before program 5 is due. 
