//program2.hpp
//Colton Roach
//September 25, 2022

#ifndef PROGRAM2_HPP
#define PROGRAM2_HPP

extern string token;

#endif
