//program1.hpp
//Colton Roach
//September 5, 2022

#ifndef PROGRAM1_HPP
#define PROGRAM1_HPP

extern int type;

#endif
