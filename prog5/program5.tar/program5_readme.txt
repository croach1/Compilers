Fixed shift reduce errors and a bunch of other stuff from last time. Currently has two 
issues that I'm just going to leave for the sake of time and stress: no error handling
and doesn't handle nested sub blocks like

int foo(){
    {
        {
            {
                int x;
            }
        }
    }
}

It just puts all variables in the first level of sub block. Hopefully those things
won't cost me too much.
