Here are the input/output files asked for. I recycled the input files from the
last program. 

When using the 4_errors.decaf file, only the LAST error should be 'available'. 

I do not REQUIRE that you have a "type" table. As long as when we do type
checking, you can determine that a class name is a type. I also do not insist
that you have separate tables for sub-blocks. BUT if they have variables
declared in them you better be able to differentiate based on scope. 
